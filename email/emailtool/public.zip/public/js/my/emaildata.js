//定义全局变量
head.ready(function () {


    /*  页面开始渲染  */

    app.m.product1 = new app.model.Product({
        productid:12310,
        productname: "皇室新小蜜蜂床边音乐铃",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product2 = new app.model.Product({
            productid:12310312,
            productname: "皇室新32131",
            productintro :"早期感官发育 适合0岁以上宝宝",
            producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
            productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
            productmarketprice: 20,
            productfinalprice:10
    });

    app.m.product3 = new app.model.Product({
        productid:1231033,
        productname: "皇室新小蜜蜂4444",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product4 = new app.model.Product({
        productid:12310312123,
        productname: "皇室新666",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });
	
    app.m.product5 = new app.model.Product({
        productid:123102233,
        productname: "皇室新小888蜂4444",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product6 = new app.model.Product({
        productid:1231033312123,
        productname: "皇室新77",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product7 = new app.model.Product({
        productid:99,
        productname: "皇室新小888蜂4444",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product8 = new app.model.Product({
        productid:9999,
        productname: "皇室新77",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product9 = new app.model.Product({
        productid:888,
        productname: "皇室新小888蜂4444",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.m.product10 = new app.model.Product({
        productid:88888,
        productname: "皇室新77",
        productintro :"早期感官发育 适合0岁以上宝宝",
        producturl : "http://www.muyingzhijia.com/shopping/productdetail.aspx?pdtID=81360&ctlid=433&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123" ,
        productpic : "http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_10.jpg",
        productmarketprice: 20,
        productfinalprice:10
    });

    app.co.plist1 = new app.collection.Productlist();
    app.co.plist1.add(app.m.product1);
    app.co.plist1.add(app.m.product2);
    app.co.plist1.add(app.m.product3);
    app.co.plist1.add(app.m.product4);
    app.co.plist1.add(app.m.product5);
    app.co.plist1.add(app.m.product6);
    app.co.plist1.add(app.m.product7);
    app.co.plist1.add(app.m.product8);
    app.co.plist1.add(app.m.product9);
    app.co.plist1.add(app.m.product10);


    app.m.email1 = new app.model.Email({
        emailid:null,
        emailname : '活动EDM',
        emaillink : 'http://www.muyingzhijia.com/?utm_source=myzj&utm_source=myzj&utm_source=myzj&utm_medium=email&utm_term=hv&utm_campaign=toys0123',
        headpic1 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_01.jpg',
        headpic2 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_02.jpg',
        headpic3 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_03.jpg',
        headpic4 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_05.jpg',
        headpic5 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_06.jpg',
        headpic6 : '',
        borderpic : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_07.jpg',
        bottempic1 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_68.jpg',
        bottempic2 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_69.jpg',
        bottempic3 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_70.jpg',
        bottempic4 : 'http://img.muyingzhijia.com/edm/2013/0122toys/images/baby_joy_confluence_edm0121_71.jpg',
        couponcode : 'QHUYLP',
        coupondate : '在活动价基础上抵用(有效期截至：2013/1/31)'
    });

    app.v.email1 = new app.view.Email({ model: app.m.email1, collection: app.co.plist1, el:'body' });

// 开始普通商品列表部分



});
